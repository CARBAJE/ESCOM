import struct
import cmath
import numpy as np #para el manejo de matrices excesivamente grandes
import matplotlib.pyplot as plt #graficar el espectro de frecuencia y el espectro de tiempo
import WavHeader
