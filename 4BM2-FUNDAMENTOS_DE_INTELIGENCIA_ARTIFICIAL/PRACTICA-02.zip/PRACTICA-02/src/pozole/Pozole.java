//CICLO 202-01 | 4BM2 
//Alumno: Carrillo Barreiro José Emiliano


package pozole;

public class Pozole 
{
    public static void main(String[] args) 
    {
        Tablero t =new Tablero();
        t.setVisible(true);
    }        
}