package agentes;

public class Agentes {
    public static void main(String[] args) 
    {
        Escenario e = new Escenario();
        e.setVisible(true);
    }
    
}

