package agentes;

/**
 *
 * @author macario
 * PARTICIPANTES DEL EQUIPO PARA LA ELABORACIÓN DE LA PARACTICA 01 FIA-4BM2-CICLO 2023/02.
 * -Carrillo Barreiro José Emiliano
 * -Morales Martínez Arturo.
 */
public class Agentes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        //ALL code application logic here
        
        Escenario e = new Escenario();
        e.setVisible(true);
    }
    
}
