% Hola mundo en Prolog

hola:-writeln('Hola mundo').

% Consultar:  ?- hola.
