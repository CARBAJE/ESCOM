//Pacheco Sanchez Rodrigo
//Martinez Mendez Diego
//Corona Reyes Mauricio Dassel
//4BM1  - Fundamentos de Inteligencia Artificial


package pozole;

public class Pozole 
{
    public static void main(String[] args) 
    {
        Tablero t =new Tablero();
        t.setVisible(true);
    }        
}