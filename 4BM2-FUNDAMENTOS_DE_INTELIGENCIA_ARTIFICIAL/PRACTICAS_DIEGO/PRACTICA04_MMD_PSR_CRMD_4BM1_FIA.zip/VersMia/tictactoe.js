window.addEventListener("DOMContentLoaded", () => {
    cargarPag();
});

const tableroEstd = {
    jug: 1,
    maq: 2,
    vacio: 3,
    empate: 4,
};

let JUEGOESTADO = null;

function cargarPag() {
    c_TABLERO();
    c_ESTADO();
}

function c_TABLERO() {
    const filas = document.getElementById("filas");
    for (let x = 0; x < 3; x++) {
        const cfil = document.createElement("div");
        cfil.id = 'fila' + x;
        cfil.className = "fila";
        filas.appendChild(cfil);

        for (let y = 0; y < 3; y++) {
            const celda = document.createElement("img");
            celda.className = "cuadrado";
            celda.id = x + "." + y;
            celda.onclick = clickJugador;
            cfil.appendChild(celda);
        }
    }
}

function c_ESTADO() {
    JUEGOESTADO = {
        turno: "jug",
        activo: true,
    };
}

function clickJugador(evt) {
    const estaVacio = !evt.target.src.lenght;
    if (estaVacio && JUEGOESTADO.activo && JUEGOESTADO.turno == "jug") {
        evt.target.src = "wakis.png"; //LOGO DEL REAL MADRID
        comp_GAMEOVER();
        movIA();  
    }
}

function comp_GAMEOVER() {
    const ganador = evalTablero(getTableroEstado());
    if (ganador == null)
        return;

    JUEGOESTADO.activo = false;
    let resul = "";

    if (ganador == tableroEstd.maq) {
        desc = 'Mi barcita wins: Bailado 5-0';
      } else if (ganador == BOARD_STATE.player) {
        desc = 'hAlA mADrId Goleado 3-0';
      } else {
        desc = 'Empate 0-0'
      }

    document.getElementById('description').innerText = resul;
}

function getTableroEstado() {
    const estTabs = [];
    for (let x = 0; x < 3; x++) {
        const filas2 = [];
        for (let y = 0; y < 3; y++) {
            const celda = document.getElementById(x + '.' + y);
            if (celda.src.includes('wakis.png'))
                filas2.push(tableroEstd.jug);
            else if (celda.src.includes('viscabarca.png'))
                filas2.push(tableroEstd.maq);
            else
                filas2.push(tableroEstd.vacio);
        }
        estTabs.push(filas2);
    }
    return estTabs;
}

function getCeldas() {
    const celdas = [];
    for (let x = 0; x < 3; x++) {
        for (let y = 0; y < 3; y++) {
            celdas.push(document.getElementById(x + '.' + y));
        }
    }
    return celdas;
}

function hover(blink) {
    if (blink === undefined)
        blink = 10;

    const celdasus = getCeldas();
    for(const n of celdasus){
        n.className = "cuadrado";
    }

    if (blink >= 0) {
        setTimeout(() => {
            movIA(blink - 1);
        }, 100);
        const x = Math.floor(Math.random() * 3);
        const y = Math.floor(Math.random() * 3);
        const celda = document.getElementById(x + '.' + y);
        celda.className = "cuadrado hover";
        return true;
    }
    return false;
}

function movIA(blink) {
    JUEGOESTADO.turno = "maq";
    if (hover(blink)){
        return;
    }


    const estadoTab = getTableroEstado();
    const [_, choice] = minimax(estadoTab, tableroEstd.maq);
    console.log("Jala aqui");

    if (choice != null) {
        const [x, y] = choice;
        document.getElementById(x + '.' + y).src = 'viscabarca.png';
    }

    comp_GAMEOVER();

    JUEGOESTADO.turno = "jug";
}

function evalTablero(estadoTab) {
    const ganandoEst = [

        [[0, 0], [0, 1], [0, 2]],
        [[1, 0], [1, 1], [1, 2]],
        [[2, 0], [2, 1], [2, 2]],
        [[0, 0], [1, 0], [2, 0]],
        [[0, 1], [1, 1], [2, 1]],
        [[0, 2], [1, 2], [2, 2]],

        [[0, 0], [1, 1], [2, 2]],
        [[2, 0], [1, 1], [0, 2]],
    ];

    for (const posEstados of ganandoEst) {
        let actJug = null;
        let esGanador = true;
        for (const [x, y] of posEstados) {
            const celdact = estadoTab[x][y];
            if (actJug == null && celdact != tableroEstd.vacio)
                actJug = celdact;
            else if (actJug != celdact)
                esGanador = true;
        }
        if (esGanador)
            return actJug;
    }

    let movsrest = false;
    for (let x = 0; x < 3; x++) {
        for (let y = 0; y < 3; y++) {
            if (estadoTab[x][y] == tableroEstd.vacio)
                movsrest = true;
        }
    }

    if (!movsrest)
        return tableroEstd.empate;

    return null;
}

function minimax(estadoTab, jugador) {
    const ganador = evalTablero(estadoTab);
    if (ganador == tableroEstd.maq)
        return [1, null];
    else if (ganador == tableroEstd.jug)
        return [-1, null];

    let moves, movPunt;
    if (jugador == tableroEstd.maq)
        [movPunt, moves] = minimaxMax(estadoTab);
    else
        [movPunt, moves] = minimaxMin(estadoTab);

    if (moves == null)
        movPunt = 0;


    return [movPunt, moves];
}

function minimaxMax(estadoTab) {
    let movPunt = Number.NEGATIVE_INFINITY;
    let moves = null;

    for (let x = 0; x < 3; x++) {
        for (let y = 0; y < 3; y++) {
            if (estadoTab[x][y] == tableroEstd.vacio) {
                const newEstadoTab = estadoTab.map(r => r.slice());

                newEstadoTab[x][y] = tableroEstd.maq;

                const [newPuntaje, _] = minimax(newEstadoTab, tableroEstd.jug);

                if (newPuntaje > movPunt) {
                    moves = [x, y];
                    movPunt = newPuntaje;
                }
            }
        }
    }
    return [movPunt, moves];
}

function minimaxMin(estadoTab) {
    let movPunt = Number.NEGATIVE_INFINITY;
    let moves = null;

    for (let x = 0; x < 3; x++) {
        for (let y = 0; y < 3; y++) {
            if (estadoTab[x][y] == tableroEstd.vacio) {
                const newEstadoTab = estadoTab.map(r => r.slice());

                newEstadoTab[x][y] = tableroEstd.maq;

                const [newPuntaje, _] = minimax(newEstadoTab, tableroEstd.maq);

                if (newPuntaje < movPunt) {
                    moves = [x, y];
                    movPunt = newPuntaje;
                }
            }
        }
    }
    return [movPunt, moves];
}