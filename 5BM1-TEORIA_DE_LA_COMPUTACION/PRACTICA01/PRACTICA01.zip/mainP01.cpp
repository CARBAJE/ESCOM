//MAIN
#include "PRACTICA01.h"

int main(){
    int error = 0;
    menu(error);

    return error;
}
