package com.clases2;
public class Main{
    public static void main(String[] args){
        CentroComercial plaza = new CentroComercial(null);
        plaza.setDomicilio("Av. Siempre Viva 123");
        plaza.setSuperficie(45433);
        plaza.setNombre("Plaza Oprima");
        plaza.setTelefono("1234567890");
        plaza.setNumTiendas(100);
        plaza.setNumPlantas(3);
        plaza.setTienda(null);
        plaza.setRestaurante(null);
        plaza.setEstacionamiento(null);
        plaza.abrirCentroComercial();
        plaza.informe();

        Estacionamiento estacionamiento = new Estacionamiento();
        estacionamiento.Constructor(0, 100, 5, 20, 1000, 0.0);
        estacionamiento.IngresarCarro(10);
        estacionamiento.setPorcLlenado(0.0);
        estacionamiento.Informe();
        Restaurante restaurante = new Restaurante();
        restaurante.Constructor("El Rincon de la Abuela", "Sopa de Tortilla", 0, 10, 100, 0.0f);
        restaurante.AgregarComensal(10);
        restaurante.setPorcOcupado(0.0f);
        restaurante.Informe();
        TiendaDepartamental tienda = new TiendaDepartamental();
        tienda.Constructor("Liverpool", "Ropa", 3, 10, 10330, 12000);
        tienda.CambiarProducto("Electronica");
        tienda.informe();
    }

}
